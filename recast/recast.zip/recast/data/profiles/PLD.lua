return {
    mode = 'blacklist',
    hide_spells = {
    },
    hide_ja = {
    },
    only_spells = {
        ['Cure IV'] = true,
        ['Cure III'] = true,
        ['Crusade'] = true,
        ['Enlight II'] = true,
        ['Absorb-TP'] = true,
        ['Stoneskin'] = true,
        ['Stun'] = true,
        ['Protect V'] = true,
    },
    only_ja = {
        ['Holy Circle'] = true,
        ['Cover'] = true,
        ['Shield Bash'] = true,
        ['Divine Emblem'] = true,
        ['Chivalry'] = true,
        ['Rampart'] = true,
        ['Invincible'] = true,
        ['Fealty'] = true,
        ['Sepulcher'] = true,
        ['Majesty'] = true,
        ['Souleater'] = true,
        ['Palisade'] = true,
        ['Sentinel'] = true,
        ['Intervene'] = true,
        ['Last Resort'] = true,
    },
}
