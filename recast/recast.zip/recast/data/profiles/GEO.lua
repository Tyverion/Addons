return {
    mode = 'blacklist',
    hide_spells = {
    },
    hide_ja = {
    },
    only_spells = {
        ['Stun'] = true,
    },
    only_ja = {
    },
}
